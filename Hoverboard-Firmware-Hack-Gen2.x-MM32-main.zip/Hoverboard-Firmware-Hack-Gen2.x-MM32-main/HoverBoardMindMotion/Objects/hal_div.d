./objects/hal_div.o: Library\MM32SPIN05\HAL_Lib\Src\hal_div.c \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_div.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\types.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_common.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm0.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_div.h
