./objects/main.o: Src\main.c \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\mm32_device.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\mm32_reg.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\types.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_common.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\ARM\CMSIS\6.3.0\CMSIS\Core\Include\core_cm0.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_adc.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_bkp.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_can.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_comp.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_crc.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_dbg.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_div.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_dma.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_exti.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_flash.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_gpio.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_i2c.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_iwdg.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_pwr.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_rcc.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_spi.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_syscfg.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_tim.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_uart.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\reg_wwdg.h \
  C:\Users\clgau\AppData\Local\Arm\Packs\MindMotion\MM32SPIN0x_DFP\1.0.8\Device\MM32SPIN06xx_s\Include\mm32_reg_redefine_v1.h \
  RTE\_MM32SPIN05\RTE_Components.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_gpio.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_rcc.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_adc.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_tim.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_iwdg.h Src\..\Inc\delay.h \
  Src\..\Inc\pinout.h Src\..\Inc\..\Inc\hardware.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_conf.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_crc.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_comp.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_dbg.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_div.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_dma.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_exti.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_flash.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_i2c.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_misc.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_pwr.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_spi.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_syscfg.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_uart.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_uid.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_wwdg.h \
  Library\MM32SPIN05\HAL_Lib\Inc\hal_redefine.h Src\..\Inc\initialize.h \
  Src\..\Inc\uart.h Src\..\Inc\bldc.h Src\..\Inc\sim_eeprom.h \
  Src\..\Inc\hardware.h Src\..\Inc\calculation.h Src\..\Inc\ipark.h \
  Src\..\Inc\FOC_Math.h Src\..\Inc\pwm_gen.h Src\..\Inc\PID.h \
  Src\..\Inc\hallhandle.h Src\..\Inc\..\Inc\pinout.h
